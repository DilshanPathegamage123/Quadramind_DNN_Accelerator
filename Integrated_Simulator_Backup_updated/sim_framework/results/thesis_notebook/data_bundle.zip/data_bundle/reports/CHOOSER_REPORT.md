# Configuration-Chooser Report — analytical stationary × layout × casting selection

**Date:** 2026-07-18 · **Branch:** `fix/chooser-accuracy` (accuracy fixes
on top of `feature/config-chooser`, itself on the verified-fix stack
ending at `golden-check/visual-summary`) · **Module:**
`pysim/config_chooser.py` · **CLI:** `scripts/choose_config.py` ·
**Evaluation:** `scripts/eval_chooser.py`

**Accuracy fixes applied on this branch:** Issue 1 — deliberate tie-break
(latency rank, then energy) with explicit tie reporting; Issue 2 —
dataflow-aware WS re-fetch term derived from the harness invocation loop,
measured-exact on all four recorded WS runs; Issue 3 — honest speed
figures (warm scoring vs one-time imports vs cold end-to-end). Open:
Issue 4 — IS/OS cycle-model resolution (§1.4).

Given a DNN workload (layer shapes), a fixed array size, and a memory
provision, the chooser scores **all 27 combinations** of stationary scheme
(OS/WS/IS) × memory layout (ROW/COLUMN/CHANNEL_MAJOR) × casting scheme
(MULTICAST/UNICAST/HYBRID) with the existing analytical cost model, ranks
them by a user-chosen goal, and returns the best combination plus the full
ranked table. **No RTL is run per query and no number is invented** — every
value is either computed by the reused validated formulas (**model**) or
quoted from the recorded Verilator results (**measured**).

## 1. Design

### 1.1 Reused validated formulas (imported, not copied)

| Metric | Source | Role |
|---|---|---|
| Cycle rank score | `pysim.software_ref.estimate_cycles` | OS/IS/WS FSM cycle estimate — **ranks configurations only**; it does not predict absolute cycles (documented in GOLDEN_CHECK_SUMMARY.md §7) |
| Layout penalty | `scripts.run_full_eval.compute_layout_factor` | per-tensor DRAM penalty (OS→output, IS→input, WS→weight), re-based so it composes with casting without double counting |
| Energy | `run_full_eval.DRAM_PJ_PER_BYTE` (560 pJ/B), `COMPUTE_PJ_PER_MAC` (0.5 pJ) | energy = off-chip bytes × 560 + MACs × 0.5 × (dw/8) — same formula as `run_full_eval.sim_layer` |
| Memory-fit penalty | the scratchpad-capacity formula from `run_full_eval.run_hardware_sweep` | 1 + 0.3·log₂(working-set/capacity + 1) when the layer working set exceeds the provision |

### 1.2 Casting model — structural, RTL-anchored (decision confirmed by user)

`run_full_eval._casting_traffic` ties casting to a dataflow and cannot
reproduce the measured casting ordering, so the chooser instead uses the
**structural prefetcher-walk model** — the per-tile formulas stated in
CASTING_FIX_REPORT.md §8, expressed structurally (no hard-coded ratios):

```
weights (multicast) = valid_rows · C·KH·KW        per tile
inputs  (multicast) = C·KH·(W+KW−1)               per tile (halo dedup)
weights (unicast)   = multicast × W               (row-broadcast consumers)
inputs  (unicast)   = C·KH·KW · W · H             (one read per consuming PE)
hybrid              = weights multicast + inputs unicast
```

summed over the tile grid `ceil(K/H) × OH × ceil(OW/W)`. This reproduces
**all six measured whole-layer casting beat counts exactly** (§4d) and its
structure is confirmed at other array widths by the measured WS 8×1/8×2/8×8
runs (§4d).

### 1.3 Ranking metrics (per confirmed decisions)

- **`--goal offchip` (primary):** model off-chip elements = casting-walk
  weight+input elements + output writeback, layout penalty applied to the
  dataflow-affected tensor, memory-fit penalty on the total. **Model.**
- **`--goal latency`:** rank score = Σ `estimate_cycles`·layout_factor +
  prefetch beats (each beat occupies the single AXI read-data port one
  cycle). **Rank only — never an absolute cycle prediction.**
- **`--goal energy`:** the reused energy formula on the off-chip bytes.
  **Model.**
- **`--goal weighted`:** each metric normalised by its best across the 27,
  user weights via `--weights offchip=..,latency=..,energy=..`.

### 1.4 Known model-vs-hardware divergences (stated plainly, not buried)

1. **Layout: volume vs structure.** The analytical `compute_layout_factor`
   varies traffic **volume** by layout. The measured RTL moves an
   **identical beat volume** in every layout (tiny L0: 1,836 beats for
   RM/CM/ChM alike) and instead changes **AR-request count and cycles**
   (ChM 138 AR / 5,808 cyc vs RM/CM 1,794 AR / 10,776 cyc — burst
   coalescing). The layout *ordering* agrees (CHANNEL_MAJOR best for OS,
   measured and modelled); the per-layout traffic deltas are model values
   with no measured counterpart.
2. **WS per-invocation re-fetch — FIXED on `fix/chooser-accuracy`
   (Issue 2).** The prefetch model is now dataflow-aware: WS traffic is
   computed by replicating the harness's diagonal invocation loop
   (`_harness_ws`, tb/golden/test_golden_single.py — diagonals
   d ∈ [−(OH−1), K), oh0 blocks stepped by H, × OW × C), one prefetcher
   walk per invocation, with zero fitted constants. Validated **exactly**
   against all four measured WS runs — tiny 8×1/8×2/8×8: 43,254 / 45,360 /
   57,996 beats (234 invocations each) and mnist 8×8: 80,964 beats
   (858 invocations) — so the term scales structurally across array
   widths rather than being fitted at one width. Before the fix WS-CM-MU
   sat in the rank-1 tie at 5,584 elements on tiny 8×8; after, WS configs
   occupy ranks 19–27 (WS-CM-MU: 3,541,936 model elements, dominated by
   the 1,152-invocation re-fetch on the 288-channel dense layer — that
   layer's WS traffic is a structural extrapolation of the same validated
   loop; no measured WS run of it exists). No recommendation changed (WS
   never won a goal); only the false tie was removed. OS/IS traffic is
   unchanged and still matches measured exactly.
3. **Latency across dataflows — open Issue 4: IS/OS cycle-model
   resolution.** Measured cycles put **IS fastest** on both anchors
   (5,220 vs OS 5,808 tiny, −11.3 %; 32,136 vs 36,712 mnist, −14.2 %);
   the model's latency rank puts OS first by a genuine but tiny 0.09 %
   margin. The model therefore under-resolves the OS/IS gap by roughly
   two orders of magnitude. This is a **distinct open item** — it is a
   cycle-estimator resolution limit, separate from the WS re-fetch term
   (Issue 2), and is **not** fixed by tie-breaking (Issue 1) or by the WS
   traffic correction; closing it needs a finer per-dataflow cycle model
   against measured RTL. Quantified as the measured optimality gap in §4b.

## 2. Example run

```
$ PYTHONPATH=. python scripts/choose_config.py \
      --workload models/tiny_cnn --array 8x8 --mem 256KB --goal offchip

Model libraries loaded in 749 ms (one-time per process); scored 27
combinations analytically in 0.8 ms (no RTL run).

RECOMMENDED: OS + CHANNEL_MAJOR + MULTICAST
  off-chip elements : 5,584  (model)
  latency rank score: 5,649  (rank only -- not a cycle prediction)
  energy            : 6.26 uJ  (model)

  NOTE: 2 configurations tie exactly at 5,584 on --goal offchip:
        OS-ChM-MU, IS-RM-MU
  Tie broken by latency rank, then energy
        (latency ranks: OS-ChM-MU 5,649, IS-RM-MU 5,654).

  # config          offchip elems  latency rank  energy (uJ)  weighted
  1 OS-ChM-MU               5,584         5,649         6.26     3.000
  2 IS-RM-MU                5,584         5,654         6.26     3.001
  3 OS-CM-MU                5,640         5,653         6.33     3.021
  ...
  7 OS-ChM-HY              31,540        31,605        35.33    16.885
 13 OS-ChM-UN              48,676        48,741        54.53    26.051
 19 WS-CM-MU            3,541,936     3,542,090     3,966.98  1894.729
 27 WS-RM-UN           29,616,156    28,569,515    33,170.10 15657.393
```

Full table: `results/chooser/ranked_tiny_cnn_offchip.csv` (27 rows, every
value tagged `model`). The three-way tie at rank 1–3 is real model
behaviour: prefetch traffic is dataflow-independent and each dataflow's
optimal layout carries zero penalty, so {OS-ChM, WS-CM, IS-RM} score
identically on off-chip traffic at equal casting.

**Tie handling (corrected on `fix/chooser-accuracy`):** exact ties on the
goal metric are reported explicitly in the CLI output and broken by a
deliberate, documented criterion — **latency rank first, then energy** —
never by enumeration order. (An earlier revision of this report claimed
"the latency rank breaks the tie"; that was incorrect — the sort was
stable on the goal metric alone, so tied configurations were silently
ordered by enumeration order (OS, WS, IS). The 4×4 case exposed it:
IS-RM-MU had the best latency rank of the tied set yet OS-ChM-MU was
recommended. With the fix, the 4×4 off-chip recommendation is IS-RM-MU.)

## 3. How the chooser decides (summary of behaviour)

Across all 14 evaluation workloads (7 edge + 7 cloud, 4 layers each) and
both anchor models, at 8×8/256 KB the chooser's off-chip winner is
**MULTICAST casting with the winning dataflow's matched layout**: OS-ChM
and IS-RM tie exactly (tie broken by latency rank — OS at 8×8, IS at
narrow/small arrays such as 8×1 and 4×4), then hybrid (~5.6× more traffic
on tiny), then unicast (~8.7×). WS configurations rank last (19–27) since
the Issue 2 fix prices their measured per-invocation re-fetch. This
matches the measured casting behaviour (multicast fewest, unicast most,
hybrid strictly between, on every measured metric) and the measured WS
traffic penalty (57,996 vs 1,836 beats on tiny L0).

## 4. Evaluation — four results, real numbers

### (a) Decision accuracy — 56/56

For every workload × goal (14 × 4), the chooser's top pick equals the true
best from an independent exhaustive re-scoring pass: **56/56 (100 %)**.
Honesty note (per the confirmed eval design): the chooser **is** exhaustive
over the 27-combo space — exhaustive scoring is the correct algorithm at
this size, and this check verifies argmin/sort consistency and determinism,
not a heuristic's luck. On the anchors, axis-level agreement with
**measured hardware** is: casting axis 8/8, layout axis 8/8, dataflow axis
6/8 (the two latency cases — §b). Data:
`eval_decision_accuracy.csv`, `eval_anchor_decisions.csv`.

### (b) Optimality gap

- **Model vs model:** 0.0000 % mean and max (pick == best in all 56 cases).
  Ties at the best cost are real and now explicit: after the Issue 2 fix,
  28 of 56 cases have a 2-way tie ({OS-ChM, IS-RM} on the offchip/energy
  goals) and 28 a unique best; ties resolve by the documented rule
  (latency rank, then energy). Median margin from the best to the next
  *distinct* cost is 0.08 %.
- **Against measured hardware (anchors, `--goal latency`):** the chooser
  picks OS-ChM-MULTICAST; the measured-fastest configuration is
  IS-ChM-MULTICAST. Measured cycle gap of the pick vs the hardware best:
  **+11.3 % on tiny_cnn L0** (5,808 vs 5,220 cycles) and **+14.2 % on
  mnist_cnn L0** (36,712 vs 32,136 cycles) — both cycle counts **measured
  (RTL)**. For offchip/energy/weighted goals the pick matches the measured
  best-or-tied configuration (gap 0).

### (c) Speed — measured chooser vs recorded-RTL lower bound

**Correction (Issue 3, `fix/chooser-accuracy`):** an earlier revision of
this report claimed "2.1 ms per workload". That figure was **warm scoring
only**, while the CLI at the time printed one combined timer whose first
scoring call silently included the one-time Python library import
(pandas/matplotlib/optimizer via `run_full_eval`) — hence the 557–1,507 ms
"Scored in…" lines users actually saw. The CLI now measures and prints the
two costs separately ("Model libraries loaded in … ms (one-time per
process); scored 27 combinations analytically in … ms"), and the harness
measures both warm and cold honestly. Warm scoring is also slower than the
old claim because the Issue 2 WS diagonal walk does real per-diagonal work.

| What | Time | Source |
|---|---|---|
| Chooser WARM scoring: 27 combos, one workload (median of 14 workloads × 5 reps; **excludes** one-time imports) | **15 ms** | measured |
| Chooser WARM per-config scoring cost | **0.6 ms** | measured |
| Chooser WARM: all 14 workloads × 27 combos | **237 ms** | measured |
| Chooser COLD CLI end-to-end (interpreter start + imports + scoring + table print + CSV; median of 3 subprocess runs) | **1.14 s** | measured |
| Chooser: 648-config sweep (27 × 6 arrays × 4 mem sizes, warm) | **17 ms** | measured |
| RTL, 27 combos, tiny L0 only — lower bound | **≥ 147 s** | derived from recorded `wall_seconds` of the real golden runs |
| RTL, 27 combos, mnist L0 only — lower bound | **≥ 750 s** | derived from recorded `wall_seconds` |
| Hardware synthesis per config | infeasible per query | no number claimed |

The RTL lower bound = 9 dataflow×layout combos per casting × the recorded
same-casting OS/ChM run time (tiny: 1.3/5.5/9.5 s for MC/HY/UC; mnist:
4.1/26.5/52.7 s — `results/golden_check/raw/*_verdict.json`). It is a firm
lower bound: recorded WS runs cost 4–13× the OS runs (16.7 s vs 1.3 s on
tiny), and `wall_seconds` excludes Verilator build time. Even on the
honest **cold end-to-end** figure (1.14 s), the chooser is ~130× faster
than the tiny-L0 RTL lower bound and ~660× faster than mnist L0; on warm
scoring (the number that matters inside a sweep loop) it is 4–5 orders of
magnitude faster, and a 648-config array×memory sweep costs 17 ms versus
an extrapolated hour-plus of RTL simulation per layer before build time.

### (d) Anchor check — rankings vs verified hardware

**Casting traffic (model must equal measured beats exactly) — 6/6 exact:**

| Anchor (8×8, whole layer) | Model | Measured (RTL) | Match |
|---|---|---|---|
| tiny L0 MULTICAST | 1,836 | 1,836 | exact |
| tiny L0 HYBRID | 11,664 | 11,664 | exact |
| tiny L0 UNICAST | 20,736 | 20,736 | exact |
| mnist L0 MULTICAST | 10,608 | 10,608 | exact |
| mnist L0 HYBRID | 67,392 | 67,392 | exact |
| mnist L0 UNICAST | 119,808 | 119,808 | exact |

Measured source: CASTING_FIX_REPORT.md §5 / `figures/f4_data_delivery_traffic.csv`.

**WS dataflow walk (Issue 2) — 4/4 exact, beats AND invocation counts:**

| Anchor (WS, MULTICAST, whole layer) | Model | Measured (RTL) | Match |
|---|---|---|---|
| tiny L0 8×1 | 43,254 / 234 inv | 43,254 / 234 inv | exact |
| tiny L0 8×2 | 45,360 / 234 inv | 45,360 / 234 inv | exact |
| tiny L0 8×8 | 57,996 / 234 inv | 57,996 / 234 inv | exact |
| mnist L0 8×8 | 80,964 / 858 inv | 80,964 / 858 inv | exact |

Measured source: `raw/tiny_cnn_layer_00_WS_*_b4.json`,
`raw/mnist_cnn_layer_00_WS_CHANNEL_MAJOR_STAMP_8x8_b4_wsmnist.json`.
Anchor total: **10/10 exact** beat matches (6 casting + 4 WS).

**Dataflow axis after the fixes — stated explicitly:** for the offchip,
energy, and weighted goals the pick (OS-ChM-MULTICAST) matches the
measured best-or-tied configuration, and WS is no longer falsely tied
(axis: 6/8, unchanged in count but qualitatively stronger — the WS
traffic model is now measured-exact where a measurement exists). For the
**latency goal the pick still does not match the measured-fastest
configuration**: the chooser picks OS while measured hardware runs IS
fastest (5,220 vs 5,808 cycles tiny; 32,136 vs 36,712 mnist). This is not
forced to agree: the cycle estimator resolves the OS/IS difference at
only ~0.09 % while the hardware gap is 11–14 % — the open **Issue 4**
(IS/OS cycle-model resolution, §1.4), which neither the tie-break
(Issue 1) nor the WS term (Issue 2) addresses.

**Structure at other array widths (measured WS 8×1/8×2/8×8, MULTICAST,
234 invocations, whole layer):** subtracting the structural input-halo term
`invocations × C·KH·(W+KW−1)` (27/36/90 per invocation at W=1/2/8) from the
measured beats (43,254 / 45,360 / 57,996) leaves **exactly 36,936 beats at
all three widths** — the weight-multicast term is W-invariant and the
input-halo term scales exactly as the structural formula, confirming the
model generalises beyond 8×8 rather than being fitted to it. (These runs
are MULTICAST; the ×W/×H unicast replication factors are confirmed at 8×8
by the casting runs above.)

**Ordering vs measured:** casting ordering MULTICAST < HYBRID < UNICAST —
model and measured agree on every metric, both anchors. Layout ordering for
OS — model and measured agree ChM best (measured single-tile cycles:
968 ChM < 1,796 RM = CM at MULTICAST; whole-layer 5,808 < 10,776;
CASTING_FIX_REPORT §6, f4 CSV); the measured RM == CM tie appears in the
model as a 0.04 % near-tie rather than an exact tie. The divergences that
do exist (layout volume-vs-structure, WS re-fetch, IS latency) are itemised
in §1.4 with their measured evidence.

## 5. Labels

- **measured (RTL):** every beat/cycle/AR/wall-seconds value quoted from
  `results/golden_check/` (raw JSONs, CASTING_FIX_REPORT.md, f4/f5 CSVs).
- **model:** every chooser score (off-chip elements, latency rank, energy).
  The latency rank is never an absolute cycle prediction.
- **derived:** the RTL 27-combo time lower bounds (arithmetic on recorded
  `wall_seconds`).

## 6. Regression safety

This change adds three Python files and this report; **no RTL, no golden
harness, no `pysim/sim_config.py`, and no existing experiment result was
modified** (`git status`: additions only). The 19/19 golden regression
outcome is therefore unchanged by construction; it was **not** re-run,
because `run_golden.py` writes into `results/golden_check/raw/` and
re-running would overwrite recorded experiment results, which this task
explicitly forbids.

## 7. Files

- `pysim/config_chooser.py` — cost-model wrapper + 27-combo ranking
- `scripts/choose_config.py` — CLI (`--workload --array --mem --goal
  [--weights] [--csv]`), prints table, exports CSV
- `scripts/eval_chooser.py` — the four evaluations above
- `results/chooser/ranked_*.csv`, `eval_decision_accuracy.csv`,
  `eval_speed.csv`, `eval_anchor_beats.csv`, `eval_anchor_decisions.csv`
